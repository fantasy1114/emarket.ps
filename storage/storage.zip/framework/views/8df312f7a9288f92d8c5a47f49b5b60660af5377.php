<div class="col-lg-3 col-md-6 col-sm-6">
    <div class="single-grid total-orders">
        <h4><?php echo e(trans('admin::dashboard.total_orders')); ?></h4>

        <i class="fa fa-shopping-cart pull-left" aria-hidden="true"></i>
        <span class="pull-right"><?php echo e($totalOrders); ?></span>
    </div>
</div>
<?php /**PATH /home1/emarket/public_html/Modules/Admin/Resources/views/dashboard/grids/total_orders.blade.php ENDPATH**/ ?>