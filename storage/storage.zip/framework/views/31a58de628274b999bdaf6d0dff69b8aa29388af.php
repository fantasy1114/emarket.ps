<?php $__env->startSection('filters'); ?>
    <div class="form-group">
        <label for="keyword"><?php echo e(trans('report::admin.filters.keyword')); ?></label>
        <input type="text" name="keyword" class="form-control" id="keyword" value="<?php echo e($request->keyword); ?>">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('report_result'); ?>
    <h3 class="tab-content-title">
        <?php echo e(trans('report::admin.filters.report_types.search_report')); ?>

    </h3>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(trans('report::admin.table.keyword')); ?></th>
                    <th><?php echo e(trans('report::admin.table.results')); ?></th>
                    <th><?php echo e(trans('report::admin.table.hits')); ?></th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($data->term); ?></td>
                        <td><?php echo e($data->results); ?></td>
                        <td><?php echo e($data->hits); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="empty" colspan="8"><?php echo e(trans('report::admin.no_data')); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pull-right">
            <?php echo $report->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('report::admin.reports.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarket/public_html/Modules/Report/Resources/views/admin/reports/search_report/index.blade.php ENDPATH**/ ?>