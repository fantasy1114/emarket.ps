<div class="col-lg-3 col-md-6 col-sm-6">
    <div class="single-grid total-customers">
        <h4><?php echo e(trans('admin::dashboard.total_customers')); ?></h4>

        <i class="fa fa-users pull-left" aria-hidden="true"></i>
        <span class="pull-right"><?php echo e($totalCustomers); ?></span>
    </div>
</div>
<?php /**PATH /home1/emarket/public_html/Modules/Admin/Resources/views/dashboard/grids/total_customers.blade.php ENDPATH**/ ?>