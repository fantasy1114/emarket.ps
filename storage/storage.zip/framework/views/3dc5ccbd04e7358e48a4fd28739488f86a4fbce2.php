<th>
    <div class="checkbox">
        <input type="checkbox" class="select-all" id="<?php echo e($name ?? ''); ?>-select-all">
        <label for="<?php echo e($name ?? ''); ?>-select-all"></label>
    </div>
</th>
<?php /**PATH /home/emarket/public_html/Modules/Admin/Resources/views/partials/table/select_all.blade.php ENDPATH**/ ?>