<?php echo e(Form::password('forge_api_key', trans('setting::attributes.forge_api_key'), $errors, $settings, ['required' => true])); ?>

<?php /**PATH /home1/emarket/public_html/Modules/Setting/Resources/views/admin/settings/partials/currency_rate_exchange_services/forge.blade.php ENDPATH**/ ?>