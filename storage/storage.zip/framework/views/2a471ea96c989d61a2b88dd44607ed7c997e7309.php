<div id="description" class="tab-pane description" :class="{ active: activeTab === 'description' }">
    <?php echo $product->description; ?>

</div>
<?php /**PATH /home1/emarket/public_html/Themes/Storefront/views/public/products/show/tab_description.blade.php ENDPATH**/ ?>