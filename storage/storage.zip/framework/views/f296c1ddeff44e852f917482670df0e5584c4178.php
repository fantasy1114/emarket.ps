<section class="navigation-wrap">
    <div class="container">
        <div class="navigation-inner">
            <!--<?php echo $__env->make('public.layout.navigation.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>-->
            <?php echo $__env->make('public.layout.navigation.primary_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!--<span class="navigation-text">-->
            <!--    <?php echo e(setting('storefront_navbar_text')); ?>-->
            <!--</span>-->
            <header-search
                    :categories="<?php echo e($categories); ?>"
                    :most-searched-keywords="<?php echo e($mostSearchedKeywords); ?>"
                    initial-query="<?php echo e(request('query')); ?>"
                    initial-category="<?php echo e(request('category')); ?>"
                >
            </header-search>
        </div>
    </div>
</section>
<?php /**PATH /home1/emarket/public_html/Themes/Storefront/views/public/layout/navigation.blade.php ENDPATH**/ ?>