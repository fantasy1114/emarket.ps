<?php if(auth()->guard()->guest()): ?>
    <div class="account-details">
        <h4 class="section-title"><?php echo e(trans('storefront::checkout.account_details')); ?></h4>

        <div class="row">
            <div class="col-md-9">
                <div class="form-group">
                    <label for="email">
                        <?php echo e(trans('checkout::attributes.customer_email')); ?><span>*</span>
                    </label>

                    <input
                        type="text"
                        name="customer_email"
                        v-model="form.customer_email"
                        id="email"
                        class="form-control"
                    >

                    <span
                        class="error-message"
                        v-if="errors.has('customer_email')"
                        v-text="errors.get('customer_email')"
                    ></span>
                </div>
            </div>

            <div class="col-md-9">
                <div class="form-group">
                    <label for="phone">
                        <?php echo e(trans('checkout::attributes.customer_phone')); ?><span>*</span>
                    </label>

                    <input
                        type="text"
                        name="customer_phone"
                        v-model="form.customer_phone"
                        id="phone"
                        class="form-control"
                    >

                    <span
                        class="error-message"
                        v-if="errors.has('customer_phone')"
                        v-text="errors.get('customer_phone')"
                    ></span>
                </div>
            </div>

            <div class="col-md-18">
                <div class="form-group create-an-account-label">
                    <div class="form-check">
                        <input
                            type="checkbox"
                            name="create_an_account"
                            v-model="form.create_an_account"
                            id="create-an-account"
                        >

                        <label for="create-an-account" class="form-check-label">
                            <?php echo e(trans('checkout::attributes.create_an_account')); ?>

                        </label>
                    </div>
                </div>

                <div class="create-an-account-form" v-show="form.create_an_account" v-cloak>
                    <span class="helper-text">
                        <?php echo e(trans('storefront::checkout.create_an_account_by_entering_the_information_below')); ?>

                    </span>

                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group">
                                <label for="password">
                                    <?php echo e(trans('checkout::attributes.password')); ?><span>*</span>
                                </label>

                                <input
                                    type="password"
                                    name="password"
                                    v-model="form.password"
                                    id="password"
                                    class="form-control"
                                >

                                <span
                                    class="error-message"
                                    v-if="errors.has('billing.password')"
                                    v-text="errors.get('billing.password')"
                                >
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <input type="hidden" name="customer_email" v-model="form.customer_email">
<?php endif; ?>
<?php /**PATH /home/emarket/public_html/Themes/Storefront/views/public/checkout/create/form/account_details.blade.php ENDPATH**/ ?>