<?php $__env->startSection('filters'); ?>
    <div class="form-group">
        <label for="product"><?php echo e(trans('report::admin.filters.product')); ?></label>
        <input type="text" name="product" class="form-control" id="product" value="<?php echo e($request->product); ?>">
    </div>

    <div class="form-group">
        <label for="sku"><?php echo e(trans('report::admin.filters.sku')); ?></label>
        <input type="text" name="sku" class="form-control" id="sku" value="<?php echo e($request->sku); ?>">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('report_result'); ?>
    <h3 class="tab-content-title">
        <?php echo e(trans('report::admin.filters.report_types.products_view_report')); ?>

    </h3>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th><?php echo e(trans('report::admin.table.product')); ?></th>
                    <th><?php echo e(trans('report::admin.table.views')); ?></th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <?php if($product->trashed()): ?>
                                <?php echo e($product->name); ?>

                            <?php else: ?>
                                <a href="<?php echo e(route('admin.products.edit', $product)); ?>"><?php echo e($product->name); ?></a>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php echo e($product->viewed); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="empty" colspan="8"><?php echo e(trans('report::admin.no_data')); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="pull-right">
            <?php echo $report->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('report::admin.reports.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/emarket/public_html/Modules/Report/Resources/views/admin/reports/products_view_report/index.blade.php ENDPATH**/ ?>