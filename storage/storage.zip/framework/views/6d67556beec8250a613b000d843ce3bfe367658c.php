<div class="row">
    <div class="col-md-8">
        <?php echo $__env->make('meta::admin.meta_fields', ['entity' => $brand], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH /home1/emarket/public_html/Modules/Brand/Resources/views/admin/brands/tabs/seo.blade.php ENDPATH**/ ?>