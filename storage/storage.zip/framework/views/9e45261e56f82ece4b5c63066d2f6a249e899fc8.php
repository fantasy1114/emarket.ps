<div class="checkbox">
    <input type="checkbox" class="select-row" value="<?php echo e($entity->id); ?>" id="<?php echo e($id = str_random()); ?>">
    <label for="<?php echo e($id); ?>"></label>
</div>
<?php /**PATH /home/emarket/public_html/Modules/Admin/Resources/views/partials/table/checkbox.blade.php ENDPATH**/ ?>